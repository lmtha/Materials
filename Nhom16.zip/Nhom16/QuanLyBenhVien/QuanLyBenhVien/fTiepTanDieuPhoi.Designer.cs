﻿namespace QuanLyBenhVien
{
    partial class fTiepTanDieuPhoi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel13 = new System.Windows.Forms.Panel();
            this.tbxTiepTanTrieuChung = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel16 = new System.Windows.Forms.Panel();
            this.cbxDieuPhoiBSi = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.txbDieuPhoiMaBN = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.dataGridViewTiepTanTTBN = new System.Windows.Forms.DataGridView();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btnTiepTanThem = new System.Windows.Forms.Button();
            this.btnTiepTanSua = new System.Windows.Forms.Button();
            this.btnTiepTanXoa = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.dateTimePickerNgKham = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.tbxTiepTanCMND = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.tbxTiepTanDT = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dateTimePickerNgSinh = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.radioBtnTiepTanNu = new System.Windows.Forms.RadioButton();
            this.radioBtnTiepTanNam = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbxTiepTanTenBN = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbxTiepTanDiaChi = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabTiepTan = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.btnTiepTanTimKiem = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.txbTiepTanTimMaBN = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridViewTiepTanTimKiem = new System.Windows.Forms.DataGridView();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txbTiepTanTimSDT = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.tabPage3.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel16.SuspendLayout();
            this.panel14.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTiepTanTTBN)).BeginInit();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabTiepTan.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTiepTanTimKiem)).BeginInit();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel13);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Controls.Add(this.panel16);
            this.tabPage3.Controls.Add(this.panel14);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(729, 450);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Điều phối bệnh nhân";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.tbxTiepTanTrieuChung);
            this.panel13.Controls.Add(this.label12);
            this.panel13.Location = new System.Drawing.Point(356, 4);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(324, 37);
            this.panel13.TabIndex = 12;
            // 
            // tbxTiepTanTrieuChung
            // 
            this.tbxTiepTanTrieuChung.Location = new System.Drawing.Point(108, 7);
            this.tbxTiepTanTrieuChung.Name = "tbxTiepTanTrieuChung";
            this.tbxTiepTanTrieuChung.Size = new System.Drawing.Size(205, 20);
            this.tbxTiepTanTrieuChung.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(21, 8);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 17);
            this.label12.TabIndex = 2;
            this.label12.Text = "Triệu chứng";
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.Location = new System.Drawing.Point(356, 53);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 37);
            this.button1.TabIndex = 11;
            this.button1.Text = "Thêm phiếu khám";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(27, 92);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(673, 342);
            this.dataGridView1.TabIndex = 10;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.cbxDieuPhoiBSi);
            this.panel16.Controls.Add(this.label15);
            this.panel16.Location = new System.Drawing.Point(6, 49);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(238, 37);
            this.panel16.TabIndex = 4;
            // 
            // cbxDieuPhoiBSi
            // 
            this.cbxDieuPhoiBSi.FormattingEnabled = true;
            this.cbxDieuPhoiBSi.Location = new System.Drawing.Point(108, 4);
            this.cbxDieuPhoiBSi.Name = "cbxDieuPhoiBSi";
            this.cbxDieuPhoiBSi.Size = new System.Drawing.Size(121, 21);
            this.cbxDieuPhoiBSi.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(18, 8);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(84, 17);
            this.label15.TabIndex = 2;
            this.label15.Text = "Bác sĩ khám";
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.txbDieuPhoiMaBN);
            this.panel14.Controls.Add(this.label13);
            this.panel14.Location = new System.Drawing.Point(6, 6);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(324, 37);
            this.panel14.TabIndex = 2;
            // 
            // txbDieuPhoiMaBN
            // 
            this.txbDieuPhoiMaBN.Location = new System.Drawing.Point(108, 7);
            this.txbDieuPhoiMaBN.Name = "txbDieuPhoiMaBN";
            this.txbDieuPhoiMaBN.Size = new System.Drawing.Size(205, 20);
            this.txbDieuPhoiMaBN.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(9, 10);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 17);
            this.label13.TabIndex = 2;
            this.label13.Text = "Mã bệnh nhân";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.panel6);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(729, 450);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Thông tin bệnh nhân";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(261, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Danh sách khám bệnh";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.dataGridViewTiepTanTTBN);
            this.panel6.Controls.Add(this.panel10);
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Controls.Add(this.panel5);
            this.panel6.Controls.Add(this.panel4);
            this.panel6.Controls.Add(this.panel2);
            this.panel6.Controls.Add(this.panel3);
            this.panel6.Location = new System.Drawing.Point(6, 30);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(708, 414);
            this.panel6.TabIndex = 6;
            // 
            // dataGridViewTiepTanTTBN
            // 
            this.dataGridViewTiepTanTTBN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTiepTanTTBN.Location = new System.Drawing.Point(18, 225);
            this.dataGridViewTiepTanTTBN.Name = "dataGridViewTiepTanTTBN";
            this.dataGridViewTiepTanTTBN.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewTiepTanTTBN.Size = new System.Drawing.Size(664, 186);
            this.dataGridViewTiepTanTTBN.TabIndex = 11;
            this.dataGridViewTiepTanTTBN.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTiepTanTTBN_CellClick);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.btnTiepTanThem);
            this.panel10.Controls.Add(this.btnTiepTanSua);
            this.panel10.Controls.Add(this.btnTiepTanXoa);
            this.panel10.Location = new System.Drawing.Point(192, 175);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(324, 44);
            this.panel10.TabIndex = 10;
            // 
            // btnTiepTanThem
            // 
            this.btnTiepTanThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTiepTanThem.Location = new System.Drawing.Point(26, 3);
            this.btnTiepTanThem.Name = "btnTiepTanThem";
            this.btnTiepTanThem.Size = new System.Drawing.Size(93, 34);
            this.btnTiepTanThem.TabIndex = 10;
            this.btnTiepTanThem.Text = "Thêm";
            this.btnTiepTanThem.UseVisualStyleBackColor = true;
            this.btnTiepTanThem.Click += new System.EventHandler(this.btnTiepTanThem_Click);
            // 
            // btnTiepTanSua
            // 
            this.btnTiepTanSua.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTiepTanSua.Location = new System.Drawing.Point(220, 3);
            this.btnTiepTanSua.Name = "btnTiepTanSua";
            this.btnTiepTanSua.Size = new System.Drawing.Size(93, 34);
            this.btnTiepTanSua.TabIndex = 12;
            this.btnTiepTanSua.Text = "Sửa";
            this.btnTiepTanSua.UseVisualStyleBackColor = true;
            // 
            // btnTiepTanXoa
            // 
            this.btnTiepTanXoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTiepTanXoa.Location = new System.Drawing.Point(123, 3);
            this.btnTiepTanXoa.Name = "btnTiepTanXoa";
            this.btnTiepTanXoa.Size = new System.Drawing.Size(93, 34);
            this.btnTiepTanXoa.TabIndex = 11;
            this.btnTiepTanXoa.Text = "Xóa";
            this.btnTiepTanXoa.UseVisualStyleBackColor = true;
            this.btnTiepTanXoa.Click += new System.EventHandler(this.btnTiepTanXoa_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.dateTimePickerNgKham);
            this.panel9.Controls.Add(this.label9);
            this.panel9.Location = new System.Drawing.Point(358, 132);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(324, 37);
            this.panel9.TabIndex = 8;
            // 
            // dateTimePickerNgKham
            // 
            this.dateTimePickerNgKham.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerNgKham.Location = new System.Drawing.Point(110, 8);
            this.dateTimePickerNgKham.Name = "dateTimePickerNgKham";
            this.dateTimePickerNgKham.Size = new System.Drawing.Size(203, 20);
            this.dateTimePickerNgKham.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(23, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 17);
            this.label9.TabIndex = 2;
            this.label9.Text = "Ngày khám";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.tbxTiepTanCMND);
            this.panel8.Controls.Add(this.label8);
            this.panel8.Location = new System.Drawing.Point(28, 89);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(324, 37);
            this.panel8.TabIndex = 4;
            // 
            // tbxTiepTanCMND
            // 
            this.tbxTiepTanCMND.Location = new System.Drawing.Point(108, 7);
            this.tbxTiepTanCMND.Name = "tbxTiepTanCMND";
            this.tbxTiepTanCMND.Size = new System.Drawing.Size(205, 20);
            this.tbxTiepTanCMND.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(58, 8);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 17);
            this.label8.TabIndex = 2;
            this.label8.Text = "CMND";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.tbxTiepTanDT);
            this.panel7.Controls.Add(this.label7);
            this.panel7.Location = new System.Drawing.Point(358, 89);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(324, 37);
            this.panel7.TabIndex = 7;
            // 
            // tbxTiepTanDT
            // 
            this.tbxTiepTanDT.Location = new System.Drawing.Point(111, 7);
            this.tbxTiepTanDT.Name = "tbxTiepTanDT";
            this.tbxTiepTanDT.Size = new System.Drawing.Size(202, 20);
            this.tbxTiepTanDT.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(33, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 17);
            this.label7.TabIndex = 2;
            this.label7.Text = "Điện thoại";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dateTimePickerNgSinh);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Location = new System.Drawing.Point(358, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(324, 37);
            this.panel5.TabIndex = 5;
            // 
            // dateTimePickerNgSinh
            // 
            this.dateTimePickerNgSinh.Location = new System.Drawing.Point(113, 4);
            this.dateTimePickerNgSinh.Name = "dateTimePickerNgSinh";
            this.dateTimePickerNgSinh.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerNgSinh.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(34, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 17);
            this.label6.TabIndex = 2;
            this.label6.Text = "Ngày sinh";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.radioBtnTiepTanNu);
            this.panel4.Controls.Add(this.radioBtnTiepTanNam);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Location = new System.Drawing.Point(358, 46);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(324, 37);
            this.panel4.TabIndex = 6;
            // 
            // radioBtnTiepTanNu
            // 
            this.radioBtnTiepTanNu.AutoSize = true;
            this.radioBtnTiepTanNu.Location = new System.Drawing.Point(164, 8);
            this.radioBtnTiepTanNu.Name = "radioBtnTiepTanNu";
            this.radioBtnTiepTanNu.Size = new System.Drawing.Size(39, 17);
            this.radioBtnTiepTanNu.TabIndex = 7;
            this.radioBtnTiepTanNu.TabStop = true;
            this.radioBtnTiepTanNu.Text = "Nữ";
            this.radioBtnTiepTanNu.UseVisualStyleBackColor = true;
            // 
            // radioBtnTiepTanNam
            // 
            this.radioBtnTiepTanNam.AutoSize = true;
            this.radioBtnTiepTanNam.Location = new System.Drawing.Point(111, 8);
            this.radioBtnTiepTanNam.Name = "radioBtnTiepTanNam";
            this.radioBtnTiepTanNam.Size = new System.Drawing.Size(47, 17);
            this.radioBtnTiepTanNam.TabIndex = 6;
            this.radioBtnTiepTanNam.TabStop = true;
            this.radioBtnTiepTanNam.Text = "Nam";
            this.radioBtnTiepTanNam.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(68, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 17);
            this.label5.TabIndex = 2;
            this.label5.Text = "Phái";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tbxTiepTanTenBN);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(28, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(324, 37);
            this.panel2.TabIndex = 2;
            // 
            // tbxTiepTanTenBN
            // 
            this.tbxTiepTanTenBN.Location = new System.Drawing.Point(108, 7);
            this.tbxTiepTanTenBN.Name = "tbxTiepTanTenBN";
            this.tbxTiepTanTenBN.Size = new System.Drawing.Size(205, 20);
            this.tbxTiepTanTenBN.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(2, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tên bệnh nhân";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tbxTiepTanDiaChi);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(28, 46);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(324, 37);
            this.panel3.TabIndex = 3;
            // 
            // tbxTiepTanDiaChi
            // 
            this.tbxTiepTanDiaChi.Location = new System.Drawing.Point(108, 7);
            this.tbxTiepTanDiaChi.Name = "tbxTiepTanDiaChi";
            this.tbxTiepTanDiaChi.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbxTiepTanDiaChi.Size = new System.Drawing.Size(205, 20);
            this.tbxTiepTanDiaChi.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(54, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "Địa chỉ";
            // 
            // tabTiepTan
            // 
            this.tabTiepTan.Controls.Add(this.tabPage1);
            this.tabTiepTan.Controls.Add(this.tabPage3);
            this.tabTiepTan.Controls.Add(this.tabPage2);
            this.tabTiepTan.Location = new System.Drawing.Point(12, 12);
            this.tabTiepTan.Name = "tabTiepTan";
            this.tabTiepTan.SelectedIndex = 0;
            this.tabTiepTan.Size = new System.Drawing.Size(737, 476);
            this.tabTiepTan.TabIndex = 0;
            this.tabTiepTan.SelectedIndexChanged += new System.EventHandler(this.tabTiepTan_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.btnTiepTanTimKiem);
            this.tabPage2.Controls.Add(this.panel12);
            this.tabPage2.Controls.Add(this.dataGridViewTiepTanTimKiem);
            this.tabPage2.Controls.Add(this.panel11);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(729, 450);
            this.tabPage2.TabIndex = 3;
            this.tabPage2.Text = "Tìm kiếm";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(477, 17);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(156, 26);
            this.button2.TabIndex = 13;
            this.button2.Text = "Xem thông tin nhân viên";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnTiepTanTimKiem
            // 
            this.btnTiepTanTimKiem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTiepTanTimKiem.Location = new System.Drawing.Point(347, 13);
            this.btnTiepTanTimKiem.Name = "btnTiepTanTimKiem";
            this.btnTiepTanTimKiem.Size = new System.Drawing.Size(89, 63);
            this.btnTiepTanTimKiem.TabIndex = 3;
            this.btnTiepTanTimKiem.Text = "Tìm kiếm";
            this.btnTiepTanTimKiem.UseVisualStyleBackColor = true;
            this.btnTiepTanTimKiem.Click += new System.EventHandler(this.btnTiepTanTimKiem_Click);
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.txbTiepTanTimMaBN);
            this.panel12.Controls.Add(this.label11);
            this.panel12.Location = new System.Drawing.Point(6, 49);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(433, 37);
            this.panel12.TabIndex = 2;
            // 
            // txbTiepTanTimMaBN
            // 
            this.txbTiepTanTimMaBN.Location = new System.Drawing.Point(130, 7);
            this.txbTiepTanTimMaBN.Name = "txbTiepTanTimMaBN";
            this.txbTiepTanTimMaBN.Size = new System.Drawing.Size(205, 20);
            this.txbTiepTanTimMaBN.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(26, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 17);
            this.label11.TabIndex = 2;
            this.label11.Text = "Mã bệnh nhân";
            // 
            // dataGridViewTiepTanTimKiem
            // 
            this.dataGridViewTiepTanTimKiem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTiepTanTimKiem.Location = new System.Drawing.Point(29, 92);
            this.dataGridViewTiepTanTimKiem.Name = "dataGridViewTiepTanTimKiem";
            this.dataGridViewTiepTanTimKiem.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewTiepTanTimKiem.Size = new System.Drawing.Size(673, 342);
            this.dataGridViewTiepTanTimKiem.TabIndex = 9;
            this.dataGridViewTiepTanTimKiem.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTiepTanTimKiem_CellClick);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.txbTiepTanTimSDT);
            this.panel11.Controls.Add(this.label10);
            this.panel11.Location = new System.Drawing.Point(6, 6);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(433, 37);
            this.panel11.TabIndex = 1;
            // 
            // txbTiepTanTimSDT
            // 
            this.txbTiepTanTimSDT.Location = new System.Drawing.Point(130, 7);
            this.txbTiepTanTimSDT.Name = "txbTiepTanTimSDT";
            this.txbTiepTanTimSDT.Size = new System.Drawing.Size(205, 20);
            this.txbTiepTanTimSDT.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(33, 10);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(91, 17);
            this.label10.TabIndex = 2;
            this.label10.Text = "Số điện thoại";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(477, 50);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(156, 26);
            this.button3.TabIndex = 14;
            this.button3.Text = "Xem thông báo";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // fTiepTanDieuPhoi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(761, 500);
            this.Controls.Add(this.tabTiepTan);
            this.MaximizeBox = false;
            this.Name = "fTiepTanDieuPhoi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tiếp tân - Điều phối";
            this.Load += new System.EventHandler(this.fTiepTanDieuPhoi_Load);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTiepTanTTBN)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabTiepTan.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTiepTanTimKiem)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.ComboBox cbxDieuPhoiBSi;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox txbDieuPhoiMaBN;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.DataGridView dataGridViewTiepTanTTBN;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btnTiepTanThem;
        private System.Windows.Forms.Button btnTiepTanSua;
        private System.Windows.Forms.Button btnTiepTanXoa;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.DateTimePicker dateTimePickerNgKham;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox tbxTiepTanCMND;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox tbxTiepTanDT;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton radioBtnTiepTanNu;
        private System.Windows.Forms.RadioButton radioBtnTiepTanNam;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tbxTiepTanTenBN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tbxTiepTanDiaChi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabControl tabTiepTan;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnTiepTanTimKiem;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox txbTiepTanTimMaBN;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridViewTiepTanTimKiem;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txbTiepTanTimSDT;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dateTimePickerNgSinh;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox tbxTiepTanTrieuChung;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;

    }
}