﻿namespace QuanLyBenhVien
{
    partial class fQLTaiVu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControlQLTV = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dtgvQLTVDV = new System.Windows.Forms.DataGridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txbQLTVGiaDV = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnQLTVDVSua = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.cbxQLTVMaDV = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.txbQLTVTenDV = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.dtgvQLTVThuoc = new System.Windows.Forms.DataGridView();
            this.btnQLTVThuocSua = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txbQLTVGiaThuoc = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbxQLTVMaThuoc = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txbQLTVTenThuoc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tabControlQLTV.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvQLTVDV)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvQLTVThuoc)).BeginInit();
            this.panel13.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlQLTV
            // 
            this.tabControlQLTV.Controls.Add(this.tabPage1);
            this.tabControlQLTV.Controls.Add(this.tabPage2);
            this.tabControlQLTV.Location = new System.Drawing.Point(12, 12);
            this.tabControlQLTV.Name = "tabControlQLTV";
            this.tabControlQLTV.SelectedIndex = 0;
            this.tabControlQLTV.Size = new System.Drawing.Size(544, 450);
            this.tabControlQLTV.TabIndex = 0;
            this.tabControlQLTV.SelectedIndexChanged += new System.EventHandler(this.tabControlQLTV_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel4);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(536, 424);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Dịch vụ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dtgvQLTVDV);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.btnQLTVDVSua);
            this.panel4.Controls.Add(this.panel11);
            this.panel4.Controls.Add(this.panel12);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(530, 418);
            this.panel4.TabIndex = 9;
            // 
            // dtgvQLTVDV
            // 
            this.dtgvQLTVDV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvQLTVDV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dtgvQLTVDV.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvQLTVDV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgvQLTVDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvQLTVDV.DefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvQLTVDV.Location = new System.Drawing.Point(4, 89);
            this.dtgvQLTVDV.Name = "dtgvQLTVDV";
            this.dtgvQLTVDV.Size = new System.Drawing.Size(524, 326);
            this.dtgvQLTVDV.TabIndex = 11;
            this.dtgvQLTVDV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvQLTVDV_CellClick);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.txbQLTVGiaDV);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Location = new System.Drawing.Point(3, 46);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(198, 37);
            this.panel5.TabIndex = 5;
            // 
            // txbQLTVGiaDV
            // 
            this.txbQLTVGiaDV.Location = new System.Drawing.Point(108, 7);
            this.txbQLTVGiaDV.Name = "txbQLTVGiaDV";
            this.txbQLTVGiaDV.Size = new System.Drawing.Size(86, 20);
            this.txbQLTVGiaDV.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Giá dịch vụ";
            // 
            // btnQLTVDVSua
            // 
            this.btnQLTVDVSua.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQLTVDVSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQLTVDVSua.Location = new System.Drawing.Point(225, 46);
            this.btnQLTVDVSua.Name = "btnQLTVDVSua";
            this.btnQLTVDVSua.Size = new System.Drawing.Size(98, 36);
            this.btnQLTVDVSua.TabIndex = 8;
            this.btnQLTVDVSua.Tag = "";
            this.btnQLTVDVSua.Text = "Cập nhật giá ";
            this.btnQLTVDVSua.UseVisualStyleBackColor = true;
            this.btnQLTVDVSua.Click += new System.EventHandler(this.btnQLTVDVSua_Click);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.cbxQLTVMaDV);
            this.panel11.Controls.Add(this.label6);
            this.panel11.Location = new System.Drawing.Point(3, 3);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(198, 37);
            this.panel11.TabIndex = 1;
            // 
            // cbxQLTVMaDV
            // 
            this.cbxQLTVMaDV.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxQLTVMaDV.FormattingEnabled = true;
            this.cbxQLTVMaDV.Location = new System.Drawing.Point(108, 7);
            this.cbxQLTVMaDV.Name = "cbxQLTVMaDV";
            this.cbxQLTVMaDV.Size = new System.Drawing.Size(86, 21);
            this.cbxQLTVMaDV.TabIndex = 3;
            this.cbxQLTVMaDV.SelectedIndexChanged += new System.EventHandler(this.cbxQLTVMaDV_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(26, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 17);
            this.label6.TabIndex = 2;
            this.label6.Text = "Mã dịch vụ";
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.txbQLTVTenDV);
            this.panel12.Controls.Add(this.label7);
            this.panel12.Location = new System.Drawing.Point(225, 3);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(324, 37);
            this.panel12.TabIndex = 2;
            // 
            // txbQLTVTenDV
            // 
            this.txbQLTVTenDV.Enabled = false;
            this.txbQLTVTenDV.Location = new System.Drawing.Point(91, 7);
            this.txbQLTVTenDV.Name = "txbQLTVTenDV";
            this.txbQLTVTenDV.Size = new System.Drawing.Size(198, 20);
            this.txbQLTVTenDV.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(-1, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 17);
            this.label7.TabIndex = 2;
            this.label7.Text = "Tên dịch vụ";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel6);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(536, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Thuốc";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.dtgvQLTVThuoc);
            this.panel6.Controls.Add(this.btnQLTVThuocSua);
            this.panel6.Controls.Add(this.panel13);
            this.panel6.Controls.Add(this.panel1);
            this.panel6.Controls.Add(this.panel2);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(530, 418);
            this.panel6.TabIndex = 8;
            // 
            // dtgvQLTVThuoc
            // 
            this.dtgvQLTVThuoc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvQLTVThuoc.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dtgvQLTVThuoc.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvQLTVThuoc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgvQLTVThuoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvQLTVThuoc.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtgvQLTVThuoc.Location = new System.Drawing.Point(6, 89);
            this.dtgvQLTVThuoc.Name = "dtgvQLTVThuoc";
            this.dtgvQLTVThuoc.Size = new System.Drawing.Size(524, 326);
            this.dtgvQLTVThuoc.TabIndex = 12;
            // 
            // btnQLTVThuocSua
            // 
            this.btnQLTVThuocSua.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQLTVThuocSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQLTVThuocSua.Location = new System.Drawing.Point(226, 46);
            this.btnQLTVThuocSua.Name = "btnQLTVThuocSua";
            this.btnQLTVThuocSua.Size = new System.Drawing.Size(102, 37);
            this.btnQLTVThuocSua.TabIndex = 8;
            this.btnQLTVThuocSua.Text = "Cập nhật giá";
            this.btnQLTVThuocSua.UseVisualStyleBackColor = true;
            this.btnQLTVThuocSua.Click += new System.EventHandler(this.btnQLTVThuocSua_Click);
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.txbQLTVGiaThuoc);
            this.panel13.Controls.Add(this.label12);
            this.panel13.Location = new System.Drawing.Point(3, 46);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(210, 37);
            this.panel13.TabIndex = 5;
            // 
            // txbQLTVGiaThuoc
            // 
            this.txbQLTVGiaThuoc.Location = new System.Drawing.Point(108, 7);
            this.txbQLTVGiaThuoc.Name = "txbQLTVGiaThuoc";
            this.txbQLTVGiaThuoc.Size = new System.Drawing.Size(86, 20);
            this.txbQLTVGiaThuoc.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(33, 8);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 17);
            this.label12.TabIndex = 2;
            this.label12.Text = "Giá thuốc";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cbxQLTVMaThuoc);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(210, 37);
            this.panel1.TabIndex = 1;
            // 
            // cbxQLTVMaThuoc
            // 
            this.cbxQLTVMaThuoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxQLTVMaThuoc.FormattingEnabled = true;
            this.cbxQLTVMaThuoc.Location = new System.Drawing.Point(108, 7);
            this.cbxQLTVMaThuoc.Name = "cbxQLTVMaThuoc";
            this.cbxQLTVMaThuoc.Size = new System.Drawing.Size(86, 21);
            this.cbxQLTVMaThuoc.TabIndex = 12;
            this.cbxQLTVMaThuoc.SelectedIndexChanged += new System.EventHandler(this.cbxQLTVMaThuoc_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Mã thuốc";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txbQLTVTenThuoc);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(219, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(324, 37);
            this.panel2.TabIndex = 2;
            // 
            // txbQLTVTenThuoc
            // 
            this.txbQLTVTenThuoc.Enabled = false;
            this.txbQLTVTenThuoc.Location = new System.Drawing.Point(82, 9);
            this.txbQLTVTenThuoc.Name = "txbQLTVTenThuoc";
            this.txbQLTVTenThuoc.Size = new System.Drawing.Size(163, 20);
            this.txbQLTVTenThuoc.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(4, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tên thuốc";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(395, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(156, 26);
            this.button1.TabIndex = 12;
            this.button1.Text = "Xem thông tin nhân viên";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(233, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(156, 26);
            this.button2.TabIndex = 13;
            this.button2.Text = "Xem thông báo";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // fQLTaiVu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(568, 465);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tabControlQLTV);
            this.MaximizeBox = false;
            this.Name = "fQLTaiVu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý tài vụ";
            this.tabControlQLTV.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvQLTVDV)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvQLTVThuoc)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlQLTV;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txbQLTVGiaThuoc;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnQLTVThuocSua;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txbQLTVTenThuoc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dtgvQLTVDV;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txbQLTVGiaDV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnQLTVDVSua;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox txbQLTVTenDV;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbxQLTVMaDV;
        private System.Windows.Forms.ComboBox cbxQLTVMaThuoc;
        private System.Windows.Forms.DataGridView dtgvQLTVThuoc;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}