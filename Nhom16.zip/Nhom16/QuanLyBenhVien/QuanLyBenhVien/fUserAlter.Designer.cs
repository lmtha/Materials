﻿namespace QuanLyBenhVien
{
    partial class fUserAlter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cbxUserAlterRoleMoi = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbxUserAlterRoleCu = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnUserAlterOK = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.cbxUserAlter = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel2);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Controls.Add(this.btnUserAlterOK);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Location = new System.Drawing.Point(106, 42);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(260, 180);
            this.panel5.TabIndex = 12;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cbxUserAlterRoleMoi);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(37, 87);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(193, 36);
            this.panel2.TabIndex = 11;
            // 
            // cbxUserAlterRoleMoi
            // 
            this.cbxUserAlterRoleMoi.FormattingEnabled = true;
            this.cbxUserAlterRoleMoi.Location = new System.Drawing.Point(70, 8);
            this.cbxUserAlterRoleMoi.Name = "cbxUserAlterRoleMoi";
            this.cbxUserAlterRoleMoi.Size = new System.Drawing.Size(113, 21);
            this.cbxUserAlterRoleMoi.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Role mới";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cbxUserAlterRoleCu);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(37, 45);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(193, 36);
            this.panel1.TabIndex = 10;
            // 
            // cbxUserAlterRoleCu
            // 
            this.cbxUserAlterRoleCu.FormattingEnabled = true;
            this.cbxUserAlterRoleCu.Location = new System.Drawing.Point(70, 8);
            this.cbxUserAlterRoleCu.Name = "cbxUserAlterRoleCu";
            this.cbxUserAlterRoleCu.Size = new System.Drawing.Size(113, 21);
            this.cbxUserAlterRoleCu.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Role cũ";
            // 
            // btnUserAlterOK
            // 
            this.btnUserAlterOK.Location = new System.Drawing.Point(107, 142);
            this.btnUserAlterOK.Name = "btnUserAlterOK";
            this.btnUserAlterOK.Size = new System.Drawing.Size(113, 23);
            this.btnUserAlterOK.TabIndex = 12;
            this.btnUserAlterOK.Text = "Chấp nhận";
            this.btnUserAlterOK.UseVisualStyleBackColor = true;
            this.btnUserAlterOK.Click += new System.EventHandler(this.btnUserAlterOK_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.cbxUserAlter);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Location = new System.Drawing.Point(37, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(193, 36);
            this.panel6.TabIndex = 6;
            // 
            // cbxUserAlter
            // 
            this.cbxUserAlter.FormattingEnabled = true;
            this.cbxUserAlter.Location = new System.Drawing.Point(70, 8);
            this.cbxUserAlter.Name = "cbxUserAlter";
            this.cbxUserAlter.Size = new System.Drawing.Size(113, 21);
            this.cbxUserAlter.TabIndex = 9;
            this.cbxUserAlter.SelectedIndexChanged += new System.EventHandler(this.cbxUserAlter_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Tên user";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(508, 291);
            this.tabControl1.TabIndex = 13;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage1.Controls.Add(this.panel5);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(500, 265);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Hiệu chỉnh role";
            // 
            // fUserAlter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(532, 315);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.Name = "fUserAlter";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hiệu chỉnh user/role";
            this.Load += new System.EventHandler(this.fUserAlter_Load);
            this.panel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox cbxUserAlterRoleMoi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cbxUserAlterRoleCu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnUserAlterOK;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ComboBox cbxUserAlter;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
    }
}