﻿namespace QuanLyBenhVien
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBoxExit = new System.Windows.Forms.PictureBox();
            this.pictureBoxChangePass = new System.Windows.Forms.PictureBox();
            this.pictureBoxInfo = new System.Windows.Forms.PictureBox();
            this.pictureBoxManage = new System.Windows.Forms.PictureBox();
            this.pictureBoxReport = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxChangePass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxManage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxReport)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBoxExit);
            this.panel1.Controls.Add(this.pictureBoxChangePass);
            this.panel1.Controls.Add(this.pictureBoxInfo);
            this.panel1.Controls.Add(this.pictureBoxManage);
            this.panel1.Controls.Add(this.pictureBoxReport);
            this.panel1.Location = new System.Drawing.Point(13, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(451, 247);
            this.panel1.TabIndex = 1;
            // 
            // pictureBoxExit
            // 
            this.pictureBoxExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxExit.Image = global::QuanLyBenhVien.Properties.Resources.exit;
            this.pictureBoxExit.Location = new System.Drawing.Point(157, 126);
            this.pictureBoxExit.Name = "pictureBoxExit";
            this.pictureBoxExit.Size = new System.Drawing.Size(112, 105);
            this.pictureBoxExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxExit.TabIndex = 2;
            this.pictureBoxExit.TabStop = false;
            this.pictureBoxExit.Click += new System.EventHandler(this.pictureBoxExit_Click);
            this.pictureBoxExit.MouseEnter += new System.EventHandler(this.pictureBoxExit_MouseEnter);
            this.pictureBoxExit.MouseLeave += new System.EventHandler(this.pictureBoxExit_MouseLeave);
            // 
            // pictureBoxChangePass
            // 
            this.pictureBoxChangePass.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxChangePass.Image = global::QuanLyBenhVien.Properties.Resources.changePass;
            this.pictureBoxChangePass.Location = new System.Drawing.Point(30, 131);
            this.pictureBoxChangePass.Name = "pictureBoxChangePass";
            this.pictureBoxChangePass.Size = new System.Drawing.Size(112, 105);
            this.pictureBoxChangePass.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxChangePass.TabIndex = 1;
            this.pictureBoxChangePass.TabStop = false;
            this.pictureBoxChangePass.MouseEnter += new System.EventHandler(this.pictureBoxChangePass_MouseEnter);
            this.pictureBoxChangePass.MouseLeave += new System.EventHandler(this.pictureBoxChangePass_MouseLeave);
            // 
            // pictureBoxInfo
            // 
            this.pictureBoxInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxInfo.Image = global::QuanLyBenhVien.Properties.Resources.userInfo;
            this.pictureBoxInfo.Location = new System.Drawing.Point(30, 7);
            this.pictureBoxInfo.Name = "pictureBoxInfo";
            this.pictureBoxInfo.Size = new System.Drawing.Size(112, 105);
            this.pictureBoxInfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxInfo.TabIndex = 0;
            this.pictureBoxInfo.TabStop = false;
            this.pictureBoxInfo.Click += new System.EventHandler(this.pictureBoxInfo_Click);
            this.pictureBoxInfo.MouseEnter += new System.EventHandler(this.pictureBoxInfo_MouseEnter);
            this.pictureBoxInfo.MouseLeave += new System.EventHandler(this.pictureBoxInfo_MouseLeave);
            // 
            // pictureBoxManage
            // 
            this.pictureBoxManage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxManage.Image = global::QuanLyBenhVien.Properties.Resources.userManage;
            this.pictureBoxManage.Location = new System.Drawing.Point(148, 4);
            this.pictureBoxManage.Name = "pictureBoxManage";
            this.pictureBoxManage.Size = new System.Drawing.Size(130, 108);
            this.pictureBoxManage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxManage.TabIndex = 0;
            this.pictureBoxManage.TabStop = false;
            this.pictureBoxManage.Click += new System.EventHandler(this.pictureBoxManage_Click);
            this.pictureBoxManage.MouseEnter += new System.EventHandler(this.pictureBoxManage_MouseEnter);
            this.pictureBoxManage.MouseLeave += new System.EventHandler(this.pictureBoxManage_MouseLeave);
            // 
            // pictureBoxReport
            // 
            this.pictureBoxReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxReport.Image = global::QuanLyBenhVien.Properties.Resources.report1;
            this.pictureBoxReport.Location = new System.Drawing.Point(284, 3);
            this.pictureBoxReport.Name = "pictureBoxReport";
            this.pictureBoxReport.Size = new System.Drawing.Size(135, 126);
            this.pictureBoxReport.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxReport.TabIndex = 0;
            this.pictureBoxReport.TabStop = false;
            this.pictureBoxReport.Click += new System.EventHandler(this.pictureBoxReport_Click);
            this.pictureBoxReport.MouseEnter += new System.EventHandler(this.pictureBoxReport_MouseEnter);
            this.pictureBoxReport.MouseLeave += new System.EventHandler(this.pictureBoxReport_MouseLeave);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(298, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 45);
            this.label1.TabIndex = 3;
            this.label1.Text = "Xem thông báo";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(476, 264);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "fAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxChangePass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxManage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxReport)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBoxInfo;
        private System.Windows.Forms.PictureBox pictureBoxManage;
        private System.Windows.Forms.PictureBox pictureBoxReport;
        private System.Windows.Forms.PictureBox pictureBoxChangePass;
        private System.Windows.Forms.PictureBox pictureBoxExit;
        private System.Windows.Forms.Label label1;
    }
}