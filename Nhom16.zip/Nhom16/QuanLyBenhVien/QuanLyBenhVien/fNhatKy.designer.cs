﻿namespace QuanLyBenhVien
{
    partial class fNhatKy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.chbxNotSuccess = new System.Windows.Forms.CheckBox();
            this.chbxSuccess = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cbxNhakKiTrenBang = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbxNhakKiThaoTac = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnUserAlterOK = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.cbxNhakKiTenUser = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dtgvXemNK = new System.Windows.Forms.DataGridView();
            this.btnNKxemNK = new System.Windows.Forms.Button();
            this.btnXemNKTatca = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.cbxNKXemTable = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbxXemNK = new System.Windows.Forms.ComboBox();
            this.btnBatNK = new System.Windows.Forms.Button();
            this.btnTatNK = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvXemNK)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 41);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(512, 382);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage1.Controls.Add(this.panel5);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(504, 356);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Bật theo dõi nhật kí";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.chbxNotSuccess);
            this.panel5.Controls.Add(this.chbxSuccess);
            this.panel5.Controls.Add(this.panel2);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Controls.Add(this.btnUserAlterOK);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Location = new System.Drawing.Point(109, 6);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(280, 284);
            this.panel5.TabIndex = 13;
            // 
            // chbxNotSuccess
            // 
            this.chbxNotSuccess.AutoSize = true;
            this.chbxNotSuccess.Location = new System.Drawing.Point(140, 145);
            this.chbxNotSuccess.Name = "chbxNotSuccess";
            this.chbxNotSuccess.Size = new System.Drawing.Size(85, 17);
            this.chbxNotSuccess.TabIndex = 14;
            this.chbxNotSuccess.Text = "Not success";
            this.chbxNotSuccess.UseVisualStyleBackColor = true;
            // 
            // chbxSuccess
            // 
            this.chbxSuccess.AutoSize = true;
            this.chbxSuccess.Location = new System.Drawing.Point(40, 145);
            this.chbxSuccess.Name = "chbxSuccess";
            this.chbxSuccess.Size = new System.Drawing.Size(67, 17);
            this.chbxSuccess.TabIndex = 13;
            this.chbxSuccess.Text = "Success";
            this.chbxSuccess.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cbxNhakKiTrenBang);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(3, 87);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(227, 36);
            this.panel2.TabIndex = 11;
            // 
            // cbxNhakKiTrenBang
            // 
            this.cbxNhakKiTrenBang.FormattingEnabled = true;
            this.cbxNhakKiTrenBang.Location = new System.Drawing.Point(104, 6);
            this.cbxNhakKiTrenBang.Name = "cbxNhakKiTrenBang";
            this.cbxNhakKiTrenBang.Size = new System.Drawing.Size(113, 21);
            this.cbxNhakKiTrenBang.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Trên bảng";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cbxNhakKiThaoTac);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(37, 45);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(193, 36);
            this.panel1.TabIndex = 10;
            // 
            // cbxNhakKiThaoTac
            // 
            this.cbxNhakKiThaoTac.FormattingEnabled = true;
            this.cbxNhakKiThaoTac.Location = new System.Drawing.Point(70, 8);
            this.cbxNhakKiThaoTac.Name = "cbxNhakKiThaoTac";
            this.cbxNhakKiThaoTac.Size = new System.Drawing.Size(113, 21);
            this.cbxNhakKiThaoTac.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Thao tác";
            // 
            // btnUserAlterOK
            // 
            this.btnUserAlterOK.Location = new System.Drawing.Point(107, 182);
            this.btnUserAlterOK.Name = "btnUserAlterOK";
            this.btnUserAlterOK.Size = new System.Drawing.Size(113, 23);
            this.btnUserAlterOK.TabIndex = 12;
            this.btnUserAlterOK.Text = "Chấp nhận";
            this.btnUserAlterOK.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.cbxNhakKiTenUser);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Location = new System.Drawing.Point(37, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(193, 36);
            this.panel6.TabIndex = 6;
            // 
            // cbxNhakKiTenUser
            // 
            this.cbxNhakKiTenUser.FormattingEnabled = true;
            this.cbxNhakKiTenUser.Location = new System.Drawing.Point(70, 8);
            this.cbxNhakKiTenUser.Name = "cbxNhakKiTenUser";
            this.cbxNhakKiTenUser.Size = new System.Drawing.Size(113, 21);
            this.cbxNhakKiTenUser.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Tên user";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(504, 356);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tắt theo dõi nhật kí";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tabPage3.Controls.Add(this.dtgvXemNK);
            this.tabPage3.Controls.Add(this.btnNKxemNK);
            this.tabPage3.Controls.Add(this.btnXemNKTatca);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.cbxNKXemTable);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.cbxXemNK);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(504, 356);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Xem nhật kí";
            // 
            // dtgvXemNK
            // 
            this.dtgvXemNK.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvXemNK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvXemNK.Location = new System.Drawing.Point(9, 118);
            this.dtgvXemNK.Name = "dtgvXemNK";
            this.dtgvXemNK.Size = new System.Drawing.Size(489, 232);
            this.dtgvXemNK.TabIndex = 8;
            // 
            // btnNKxemNK
            // 
            this.btnNKxemNK.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNKxemNK.Location = new System.Drawing.Point(362, 27);
            this.btnNKxemNK.Name = "btnNKxemNK";
            this.btnNKxemNK.Size = new System.Drawing.Size(134, 30);
            this.btnNKxemNK.TabIndex = 7;
            this.btnNKxemNK.Text = "Xem nhật kí";
            this.btnNKxemNK.UseVisualStyleBackColor = true;
            // 
            // btnXemNKTatca
            // 
            this.btnXemNKTatca.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemNKTatca.Location = new System.Drawing.Point(364, 80);
            this.btnXemNKTatca.Name = "btnXemNKTatca";
            this.btnXemNKTatca.Size = new System.Drawing.Size(134, 32);
            this.btnXemNKTatca.TabIndex = 6;
            this.btnXemNKTatca.Text = "Xem tất cả";
            this.btnXemNKTatca.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(211, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 17);
            this.label5.TabIndex = 3;
            this.label5.Text = "Xem theo table";
            // 
            // cbxNKXemTable
            // 
            this.cbxNKXemTable.FormattingEnabled = true;
            this.cbxNKXemTable.Location = new System.Drawing.Point(211, 37);
            this.cbxNKXemTable.Name = "cbxNKXemTable";
            this.cbxNKXemTable.Size = new System.Drawing.Size(100, 21);
            this.cbxNKXemTable.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(50, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 17);
            this.label3.TabIndex = 1;
            this.label3.Text = "Xem theo user";
            // 
            // cbxXemNK
            // 
            this.cbxXemNK.FormattingEnabled = true;
            this.cbxXemNK.Location = new System.Drawing.Point(50, 37);
            this.cbxXemNK.Name = "cbxXemNK";
            this.cbxXemNK.Size = new System.Drawing.Size(100, 21);
            this.cbxXemNK.TabIndex = 0;
            // 
            // btnBatNK
            // 
            this.btnBatNK.Location = new System.Drawing.Point(173, 12);
            this.btnBatNK.Name = "btnBatNK";
            this.btnBatNK.Size = new System.Drawing.Size(75, 23);
            this.btnBatNK.TabIndex = 1;
            this.btnBatNK.Text = "Bật nhật kí";
            this.btnBatNK.UseVisualStyleBackColor = true;
            this.btnBatNK.Click += new System.EventHandler(this.btnBatNK_Click);
            // 
            // btnTatNK
            // 
            this.btnTatNK.Location = new System.Drawing.Point(264, 12);
            this.btnTatNK.Name = "btnTatNK";
            this.btnTatNK.Size = new System.Drawing.Size(75, 23);
            this.btnTatNK.TabIndex = 2;
            this.btnTatNK.Text = "Tắt nhật kí";
            this.btnTatNK.UseVisualStyleBackColor = true;
            this.btnTatNK.Click += new System.EventHandler(this.btnTatNK_Click);
            // 
            // fNhatKy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(536, 435);
            this.Controls.Add(this.btnTatNK);
            this.Controls.Add(this.btnBatNK);
            this.Controls.Add(this.tabControl1);
            this.Name = "fNhatKy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fNhatKy";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvXemNK)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnBatNK;
        private System.Windows.Forms.Button btnTatNK;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox cbxNhakKiTrenBang;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cbxNhakKiThaoTac;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnUserAlterOK;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ComboBox cbxNhakKiTenUser;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chbxNotSuccess;
        private System.Windows.Forms.CheckBox chbxSuccess;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbxXemNK;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbxNKXemTable;
        private System.Windows.Forms.Button btnXemNKTatca;
        private System.Windows.Forms.Button btnNKxemNK;
        private System.Windows.Forms.DataGridView dtgvXemNK;
    }
}