﻿namespace QuanLyBenhVien
{
    partial class fQLTaiNguyenNhanSu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel18 = new System.Windows.Forms.Panel();
            this.dtgvTNNSPCong = new System.Windows.Forms.DataGridView();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.txbTNNSDen = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.btnTNNSPCongThem = new System.Windows.Forms.Button();
            this.btnTNNSPCongSua = new System.Windows.Forms.Button();
            this.btnTNNSPCongXoa = new System.Windows.Forms.Button();
            this.panel23 = new System.Windows.Forms.Panel();
            this.txbTNNSTu = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.txbHienThiPC = new System.Windows.Forms.TextBox();
            this.cbxTNNSPCongMaNV = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.dtpkTNNSNgLamViec = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel13 = new System.Windows.Forms.Panel();
            this.dtgvTNNSPhong = new System.Windows.Forms.DataGridView();
            this.panel14 = new System.Windows.Forms.Panel();
            this.btnTNNSPhongThem = new System.Windows.Forms.Button();
            this.btnTNNSPhongSua = new System.Windows.Forms.Button();
            this.btnTNNSPhongXoa = new System.Windows.Forms.Button();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txbTNNSTenPhong = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txbHienThiMaNV = new System.Windows.Forms.TextBox();
            this.cbxTNNSMaNV = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dtgvTNNSNV = new System.Windows.Forms.DataGridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.btnTNNSNVThem = new System.Windows.Forms.Button();
            this.btnTNNSNVSua = new System.Windows.Forms.Button();
            this.btnTNNSNVXoa = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.cbxTNNSNV_MaPhong = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.cbxTNNSNV_LoaiNV = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txbTNNSChucVu = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txbTNNSTenNV = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dtgvTNNSLoaiNV = new System.Windows.Forms.DataGridView();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btnTNNSLoaiNVThem = new System.Windows.Forms.Button();
            this.btnTNNSLoaiNVSua = new System.Windows.Forms.Button();
            this.btnTNNSLoaiNVXoa = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txbTNNSTenLoaiNV = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage = new System.Windows.Forms.TabControl();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tabPage4.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTNNSPCong)).BeginInit();
            this.panel19.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTNNSPhong)).BeginInit();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel17.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTNNSNV)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTNNSLoaiNV)).BeginInit();
            this.panel10.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel18);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(541, 394);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Phân công";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.dtgvTNNSPCong);
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Location = new System.Drawing.Point(6, 6);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(529, 380);
            this.panel18.TabIndex = 0;
            // 
            // dtgvTNNSPCong
            // 
            this.dtgvTNNSPCong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvTNNSPCong.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dtgvTNNSPCong.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvTNNSPCong.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgvTNNSPCong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvTNNSPCong.DefaultCellStyle = dataGridViewCellStyle1;
            this.dtgvTNNSPCong.Location = new System.Drawing.Point(3, 143);
            this.dtgvTNNSPCong.Name = "dtgvTNNSPCong";
            this.dtgvTNNSPCong.Size = new System.Drawing.Size(518, 234);
            this.dtgvTNNSPCong.TabIndex = 14;
            this.dtgvTNNSPCong.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvTNNSPCong_CellClick);
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.panel21);
            this.panel19.Controls.Add(this.panel20);
            this.panel19.Controls.Add(this.panel23);
            this.panel19.Controls.Add(this.panel24);
            this.panel19.Controls.Add(this.panel25);
            this.panel19.Location = new System.Drawing.Point(0, 3);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(526, 134);
            this.panel19.TabIndex = 2;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.txbTNNSDen);
            this.panel21.Controls.Add(this.label10);
            this.panel21.Location = new System.Drawing.Point(214, 89);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(122, 37);
            this.panel21.TabIndex = 4;
            // 
            // txbTNNSDen
            // 
            this.txbTNNSDen.Location = new System.Drawing.Point(39, 10);
            this.txbTNNSDen.Name = "txbTNNSDen";
            this.txbTNNSDen.Size = new System.Drawing.Size(80, 20);
            this.txbTNNSDen.TabIndex = 4;
            this.txbTNNSDen.Text = " ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 17);
            this.label10.TabIndex = 2;
            this.label10.Text = "Đến";
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.btnTNNSPCongThem);
            this.panel20.Controls.Add(this.btnTNNSPCongSua);
            this.panel20.Controls.Add(this.btnTNNSPCongXoa);
            this.panel20.Location = new System.Drawing.Point(349, 3);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(174, 123);
            this.panel20.TabIndex = 12;
            // 
            // btnTNNSPCongThem
            // 
            this.btnTNNSPCongThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTNNSPCongThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTNNSPCongThem.Location = new System.Drawing.Point(3, 8);
            this.btnTNNSPCongThem.Name = "btnTNNSPCongThem";
            this.btnTNNSPCongThem.Size = new System.Drawing.Size(76, 44);
            this.btnTNNSPCongThem.TabIndex = 6;
            this.btnTNNSPCongThem.Text = "Thêm";
            this.btnTNNSPCongThem.UseVisualStyleBackColor = true;
            this.btnTNNSPCongThem.Click += new System.EventHandler(this.btnTNNSPCongThem_Click);
            // 
            // btnTNNSPCongSua
            // 
            this.btnTNNSPCongSua.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTNNSPCongSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTNNSPCongSua.Location = new System.Drawing.Point(3, 67);
            this.btnTNNSPCongSua.Name = "btnTNNSPCongSua";
            this.btnTNNSPCongSua.Size = new System.Drawing.Size(76, 46);
            this.btnTNNSPCongSua.TabIndex = 8;
            this.btnTNNSPCongSua.Text = "Cập nhật";
            this.btnTNNSPCongSua.UseVisualStyleBackColor = true;
            this.btnTNNSPCongSua.Click += new System.EventHandler(this.btnTNNSPCongSua_Click);
            // 
            // btnTNNSPCongXoa
            // 
            this.btnTNNSPCongXoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTNNSPCongXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTNNSPCongXoa.Location = new System.Drawing.Point(92, 8);
            this.btnTNNSPCongXoa.Name = "btnTNNSPCongXoa";
            this.btnTNNSPCongXoa.Size = new System.Drawing.Size(76, 44);
            this.btnTNNSPCongXoa.TabIndex = 7;
            this.btnTNNSPCongXoa.Text = "Xóa";
            this.btnTNNSPCongXoa.UseVisualStyleBackColor = true;
            this.btnTNNSPCongXoa.Click += new System.EventHandler(this.btnTNNSPCongXoa_Click);
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.txbTNNSTu);
            this.panel23.Controls.Add(this.label12);
            this.panel23.Location = new System.Drawing.Point(92, 89);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(123, 37);
            this.panel23.TabIndex = 3;
            // 
            // txbTNNSTu
            // 
            this.txbTNNSTu.Location = new System.Drawing.Point(36, 10);
            this.txbTNNSTu.Name = "txbTNNSTu";
            this.txbTNNSTu.Size = new System.Drawing.Size(80, 20);
            this.txbTNNSTu.TabIndex = 3;
            this.txbTNNSTu.Text = " ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(4, 11);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 17);
            this.label12.TabIndex = 2;
            this.label12.Text = "Từ ";
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.txbHienThiPC);
            this.panel24.Controls.Add(this.cbxTNNSPCongMaNV);
            this.panel24.Controls.Add(this.label13);
            this.panel24.Location = new System.Drawing.Point(3, 3);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(339, 37);
            this.panel24.TabIndex = 1;
            // 
            // txbHienThiPC
            // 
            this.txbHienThiPC.Location = new System.Drawing.Point(125, 10);
            this.txbHienThiPC.Multiline = true;
            this.txbHienThiPC.Name = "txbHienThiPC";
            this.txbHienThiPC.Size = new System.Drawing.Size(205, 21);
            this.txbHienThiPC.TabIndex = 15;
            this.txbHienThiPC.Click += new System.EventHandler(this.txbHienThiPC_Click);
            // 
            // cbxTNNSPCongMaNV
            // 
            this.cbxTNNSPCongMaNV.FormattingEnabled = true;
            this.cbxTNNSPCongMaNV.Location = new System.Drawing.Point(125, 10);
            this.cbxTNNSPCongMaNV.Name = "cbxTNNSPCongMaNV";
            this.cbxTNNSPCongMaNV.Size = new System.Drawing.Size(205, 21);
            this.cbxTNNSPCongMaNV.TabIndex = 3;
            this.cbxTNNSPCongMaNV.SelectedIndexChanged += new System.EventHandler(this.cbxTNNSPCongMaNV_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(26, 11);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 17);
            this.label13.TabIndex = 2;
            this.label13.Text = "Mã nhân viên";
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.dtpkTNNSNgLamViec);
            this.panel25.Controls.Add(this.label14);
            this.panel25.Location = new System.Drawing.Point(3, 46);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(339, 37);
            this.panel25.TabIndex = 2;
            // 
            // dtpkTNNSNgLamViec
            // 
            this.dtpkTNNSNgLamViec.Location = new System.Drawing.Point(125, 7);
            this.dtpkTNNSNgLamViec.Name = "dtpkTNNSNgLamViec";
            this.dtpkTNNSNgLamViec.Size = new System.Drawing.Size(205, 20);
            this.dtpkTNNSNgLamViec.TabIndex = 3;
            this.dtpkTNNSNgLamViec.Value = new System.DateTime(2018, 6, 26, 2, 14, 56, 0);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(20, 10);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 17);
            this.label14.TabIndex = 2;
            this.label14.Text = "Ngày làm việc";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel13);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(541, 394);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Phòng ban";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.dtgvTNNSPhong);
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Controls.Add(this.panel15);
            this.panel13.Location = new System.Drawing.Point(6, 6);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(529, 385);
            this.panel13.TabIndex = 0;
            // 
            // dtgvTNNSPhong
            // 
            this.dtgvTNNSPhong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvTNNSPhong.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dtgvTNNSPhong.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvTNNSPhong.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgvTNNSPhong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvTNNSPhong.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtgvTNNSPhong.Location = new System.Drawing.Point(5, 98);
            this.dtgvTNNSPhong.Name = "dtgvTNNSPhong";
            this.dtgvTNNSPhong.Size = new System.Drawing.Size(518, 286);
            this.dtgvTNNSPhong.TabIndex = 15;
            this.dtgvTNNSPhong.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvTNNSPhong_CellClick);
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.btnTNNSPhongThem);
            this.panel14.Controls.Add(this.btnTNNSPhongSua);
            this.panel14.Controls.Add(this.btnTNNSPhongXoa);
            this.panel14.Location = new System.Drawing.Point(117, 48);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(272, 44);
            this.panel14.TabIndex = 14;
            // 
            // btnTNNSPhongThem
            // 
            this.btnTNNSPhongThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTNNSPhongThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTNNSPhongThem.Location = new System.Drawing.Point(3, 10);
            this.btnTNNSPhongThem.Name = "btnTNNSPhongThem";
            this.btnTNNSPhongThem.Size = new System.Drawing.Size(76, 32);
            this.btnTNNSPhongThem.TabIndex = 5;
            this.btnTNNSPhongThem.Text = "Thêm";
            this.btnTNNSPhongThem.UseVisualStyleBackColor = true;
            this.btnTNNSPhongThem.Click += new System.EventHandler(this.btnTNNSPhongThem_Click);
            // 
            // btnTNNSPhongSua
            // 
            this.btnTNNSPhongSua.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTNNSPhongSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTNNSPhongSua.Location = new System.Drawing.Point(193, 9);
            this.btnTNNSPhongSua.Name = "btnTNNSPhongSua";
            this.btnTNNSPhongSua.Size = new System.Drawing.Size(76, 32);
            this.btnTNNSPhongSua.TabIndex = 7;
            this.btnTNNSPhongSua.Text = "Cập nhật";
            this.btnTNNSPhongSua.UseVisualStyleBackColor = true;
            this.btnTNNSPhongSua.Click += new System.EventHandler(this.btnTNNSPhongSua_Click);
            // 
            // btnTNNSPhongXoa
            // 
            this.btnTNNSPhongXoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTNNSPhongXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTNNSPhongXoa.Location = new System.Drawing.Point(98, 10);
            this.btnTNNSPhongXoa.Name = "btnTNNSPhongXoa";
            this.btnTNNSPhongXoa.Size = new System.Drawing.Size(73, 32);
            this.btnTNNSPhongXoa.TabIndex = 6;
            this.btnTNNSPhongXoa.Text = "Xóa";
            this.btnTNNSPhongXoa.UseVisualStyleBackColor = true;
            this.btnTNNSPhongXoa.Click += new System.EventHandler(this.btnTNNSPhongXoa_Click);
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.panel17);
            this.panel15.Location = new System.Drawing.Point(5, 4);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(338, 51);
            this.panel15.TabIndex = 13;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.txbTNNSTenPhong);
            this.panel17.Controls.Add(this.label9);
            this.panel17.Location = new System.Drawing.Point(4, 4);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(324, 37);
            this.panel17.TabIndex = 4;
            // 
            // txbTNNSTenPhong
            // 
            this.txbTNNSTenPhong.Location = new System.Drawing.Point(108, 9);
            this.txbTNNSTenPhong.Name = "txbTNNSTenPhong";
            this.txbTNNSTenPhong.Size = new System.Drawing.Size(205, 20);
            this.txbTNNSTenPhong.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(30, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 17);
            this.label9.TabIndex = 2;
            this.label9.Text = "Tên phòng";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel4);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(541, 394);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Nhân viên";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel2);
            this.panel4.Controls.Add(this.dtgvTNNSNV);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(3, 6);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(532, 380);
            this.panel4.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txbHienThiMaNV);
            this.panel2.Controls.Add(this.cbxTNNSMaNV);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(7, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(339, 37);
            this.panel2.TabIndex = 3;
            // 
            // txbHienThiMaNV
            // 
            this.txbHienThiMaNV.Location = new System.Drawing.Point(125, 7);
            this.txbHienThiMaNV.Multiline = true;
            this.txbHienThiMaNV.Name = "txbHienThiMaNV";
            this.txbHienThiMaNV.Size = new System.Drawing.Size(97, 21);
            this.txbHienThiMaNV.TabIndex = 14;
            this.txbHienThiMaNV.Click += new System.EventHandler(this.txbHienThiMaNV_Click);
            // 
            // cbxTNNSMaNV
            // 
            this.cbxTNNSMaNV.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTNNSMaNV.FormattingEnabled = true;
            this.cbxTNNSMaNV.Location = new System.Drawing.Point(125, 7);
            this.cbxTNNSMaNV.Name = "cbxTNNSMaNV";
            this.cbxTNNSMaNV.Size = new System.Drawing.Size(97, 21);
            this.cbxTNNSMaNV.TabIndex = 6;
            this.cbxTNNSMaNV.SelectedIndexChanged += new System.EventHandler(this.cbxTNNSMaNV_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Mã nhân viên";
            // 
            // dtgvTNNSNV
            // 
            this.dtgvTNNSNV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvTNNSNV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dtgvTNNSNV.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvTNNSNV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgvTNNSNV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvTNNSNV.DefaultCellStyle = dataGridViewCellStyle3;
            this.dtgvTNNSNV.Location = new System.Drawing.Point(7, 191);
            this.dtgvTNNSNV.Name = "dtgvTNNSNV";
            this.dtgvTNNSNV.Size = new System.Drawing.Size(518, 186);
            this.dtgvTNNSNV.TabIndex = 13;
            this.dtgvTNNSNV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvTNNSNV_CellClick);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel12);
            this.panel5.Controls.Add(this.panel11);
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(526, 182);
            this.panel5.TabIndex = 1;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.btnTNNSNVThem);
            this.panel12.Controls.Add(this.btnTNNSNVSua);
            this.panel12.Controls.Add(this.btnTNNSNVXoa);
            this.panel12.Location = new System.Drawing.Point(374, 3);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(133, 166);
            this.panel12.TabIndex = 12;
            // 
            // btnTNNSNVThem
            // 
            this.btnTNNSNVThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTNNSNVThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTNNSNVThem.Location = new System.Drawing.Point(0, 3);
            this.btnTNNSNVThem.Name = "btnTNNSNVThem";
            this.btnTNNSNVThem.Size = new System.Drawing.Size(76, 44);
            this.btnTNNSNVThem.TabIndex = 6;
            this.btnTNNSNVThem.Text = "Thêm";
            this.btnTNNSNVThem.UseVisualStyleBackColor = true;
            this.btnTNNSNVThem.Click += new System.EventHandler(this.btnTNNSNVThem_Click);
            // 
            // btnTNNSNVSua
            // 
            this.btnTNNSNVSua.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTNNSNVSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTNNSNVSua.Location = new System.Drawing.Point(0, 110);
            this.btnTNNSNVSua.Name = "btnTNNSNVSua";
            this.btnTNNSNVSua.Size = new System.Drawing.Size(76, 46);
            this.btnTNNSNVSua.TabIndex = 8;
            this.btnTNNSNVSua.Text = "Cập nhật";
            this.btnTNNSNVSua.UseVisualStyleBackColor = true;
            this.btnTNNSNVSua.Click += new System.EventHandler(this.btnTNNSNVSua_Click);
            // 
            // btnTNNSNVXoa
            // 
            this.btnTNNSNVXoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTNNSNVXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTNNSNVXoa.Location = new System.Drawing.Point(0, 54);
            this.btnTNNSNVXoa.Name = "btnTNNSNVXoa";
            this.btnTNNSNVXoa.Size = new System.Drawing.Size(76, 44);
            this.btnTNNSNVXoa.TabIndex = 7;
            this.btnTNNSNVXoa.Text = "Xóa";
            this.btnTNNSNVXoa.UseVisualStyleBackColor = true;
            this.btnTNNSNVXoa.Click += new System.EventHandler(this.btnTNNSNVXoa_Click);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.cbxTNNSNV_MaPhong);
            this.panel11.Controls.Add(this.label7);
            this.panel11.Location = new System.Drawing.Point(186, 132);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(157, 37);
            this.panel11.TabIndex = 5;
            // 
            // cbxTNNSNV_MaPhong
            // 
            this.cbxTNNSNV_MaPhong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTNNSNV_MaPhong.FormattingEnabled = true;
            this.cbxTNNSNV_MaPhong.Location = new System.Drawing.Point(78, 6);
            this.cbxTNNSNV_MaPhong.Name = "cbxTNNSNV_MaPhong";
            this.cbxTNNSNV_MaPhong.Size = new System.Drawing.Size(70, 21);
            this.cbxTNNSNV_MaPhong.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(1, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 17);
            this.label7.TabIndex = 2;
            this.label7.Text = "Mã phòng";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.cbxTNNSNV_LoaiNV);
            this.panel9.Controls.Add(this.label6);
            this.panel9.Location = new System.Drawing.Point(4, 132);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(176, 37);
            this.panel9.TabIndex = 4;
            // 
            // cbxTNNSNV_LoaiNV
            // 
            this.cbxTNNSNV_LoaiNV.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTNNSNV_LoaiNV.FormattingEnabled = true;
            this.cbxTNNSNV_LoaiNV.Location = new System.Drawing.Point(102, 6);
            this.cbxTNNSNV_LoaiNV.Name = "cbxTNNSNV_LoaiNV";
            this.cbxTNNSNV_LoaiNV.Size = new System.Drawing.Size(70, 21);
            this.cbxTNNSNV_LoaiNV.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 17);
            this.label6.TabIndex = 2;
            this.label6.Text = "Loại nhân viên";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txbTNNSChucVu);
            this.panel8.Controls.Add(this.label5);
            this.panel8.Location = new System.Drawing.Point(4, 89);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(339, 37);
            this.panel8.TabIndex = 3;
            // 
            // txbTNNSChucVu
            // 
            this.txbTNNSChucVu.Location = new System.Drawing.Point(125, 7);
            this.txbTNNSChucVu.Name = "txbTNNSChucVu";
            this.txbTNNSChucVu.Size = new System.Drawing.Size(205, 20);
            this.txbTNNSChucVu.TabIndex = 3;
            this.txbTNNSChucVu.Text = " ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(60, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 17);
            this.label5.TabIndex = 2;
            this.label5.Text = "Chức vụ";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.txbTNNSTenNV);
            this.panel7.Controls.Add(this.label4);
            this.panel7.Location = new System.Drawing.Point(4, 46);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(339, 37);
            this.panel7.TabIndex = 2;
            // 
            // txbTNNSTenNV
            // 
            this.txbTNNSTenNV.Location = new System.Drawing.Point(125, 9);
            this.txbTNNSTenNV.Name = "txbTNNSTenNV";
            this.txbTNNSTenNV.Size = new System.Drawing.Size(205, 20);
            this.txbTNNSTenNV.TabIndex = 2;
            this.txbTNNSTenNV.Text = " ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(20, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "Tên nhân viên";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.dtgvTNNSLoaiNV);
            this.tabPage1.Controls.Add(this.panel10);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(541, 394);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Loại nhân viên";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dtgvTNNSLoaiNV
            // 
            this.dtgvTNNSLoaiNV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvTNNSLoaiNV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            this.dtgvTNNSLoaiNV.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgvTNNSLoaiNV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgvTNNSLoaiNV.DefaultCellStyle = dataGridViewCellStyle4;
            this.dtgvTNNSLoaiNV.Location = new System.Drawing.Point(6, 119);
            this.dtgvTNNSLoaiNV.Name = "dtgvTNNSLoaiNV";
            this.dtgvTNNSLoaiNV.Size = new System.Drawing.Size(529, 267);
            this.dtgvTNNSLoaiNV.TabIndex = 12;
            this.dtgvTNNSLoaiNV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvTNNSLoaiNV_CellClick);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.btnTNNSLoaiNVThem);
            this.panel10.Controls.Add(this.btnTNNSLoaiNVSua);
            this.panel10.Controls.Add(this.btnTNNSLoaiNVXoa);
            this.panel10.Location = new System.Drawing.Point(123, 58);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(332, 45);
            this.panel10.TabIndex = 11;
            // 
            // btnTNNSLoaiNVThem
            // 
            this.btnTNNSLoaiNVThem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTNNSLoaiNVThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTNNSLoaiNVThem.Location = new System.Drawing.Point(3, 10);
            this.btnTNNSLoaiNVThem.Name = "btnTNNSLoaiNVThem";
            this.btnTNNSLoaiNVThem.Size = new System.Drawing.Size(76, 32);
            this.btnTNNSLoaiNVThem.TabIndex = 3;
            this.btnTNNSLoaiNVThem.Text = "Thêm";
            this.btnTNNSLoaiNVThem.UseVisualStyleBackColor = true;
            this.btnTNNSLoaiNVThem.Click += new System.EventHandler(this.btnTNNSLoaiNVThem_Click);
            // 
            // btnTNNSLoaiNVSua
            // 
            this.btnTNNSLoaiNVSua.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTNNSLoaiNVSua.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTNNSLoaiNVSua.Location = new System.Drawing.Point(178, 10);
            this.btnTNNSLoaiNVSua.Name = "btnTNNSLoaiNVSua";
            this.btnTNNSLoaiNVSua.Size = new System.Drawing.Size(76, 32);
            this.btnTNNSLoaiNVSua.TabIndex = 5;
            this.btnTNNSLoaiNVSua.Text = "Cập nhật";
            this.btnTNNSLoaiNVSua.UseVisualStyleBackColor = true;
            this.btnTNNSLoaiNVSua.Click += new System.EventHandler(this.btnTNNSLoaiNVSua_Click);
            // 
            // btnTNNSLoaiNVXoa
            // 
            this.btnTNNSLoaiNVXoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTNNSLoaiNVXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTNNSLoaiNVXoa.Location = new System.Drawing.Point(94, 10);
            this.btnTNNSLoaiNVXoa.Name = "btnTNNSLoaiNVXoa";
            this.btnTNNSLoaiNVXoa.Size = new System.Drawing.Size(73, 32);
            this.btnTNNSLoaiNVXoa.TabIndex = 4;
            this.btnTNNSLoaiNVXoa.Text = "Xóa";
            this.btnTNNSLoaiNVXoa.UseVisualStyleBackColor = true;
            this.btnTNNSLoaiNVXoa.Click += new System.EventHandler(this.btnTNNSLoaiNVXoa_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Location = new System.Drawing.Point(6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(338, 50);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txbTNNSTenLoaiNV);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(3, 7);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(324, 37);
            this.panel3.TabIndex = 4;
            // 
            // txbTNNSTenLoaiNV
            // 
            this.txbTNNSTenLoaiNV.Location = new System.Drawing.Point(128, 7);
            this.txbTNNSTenLoaiNV.Name = "txbTNNSTenLoaiNV";
            this.txbTNNSTenLoaiNV.Size = new System.Drawing.Size(185, 20);
            this.txbTNNSTenLoaiNV.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tên loại nhân viên";
            // 
            // tabPage
            // 
            this.tabPage.Controls.Add(this.tabPage1);
            this.tabPage.Controls.Add(this.tabPage2);
            this.tabPage.Controls.Add(this.tabPage3);
            this.tabPage.Controls.Add(this.tabPage4);
            this.tabPage.Location = new System.Drawing.Point(12, 12);
            this.tabPage.Name = "tabPage";
            this.tabPage.SelectedIndex = 0;
            this.tabPage.Size = new System.Drawing.Size(549, 420);
            this.tabPage.TabIndex = 0;
            this.tabPage.SelectedIndexChanged += new System.EventHandler(this.dataGridViewTNNSLoaiNVdataGridViewTNNSPCong_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(401, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(156, 26);
            this.button1.TabIndex = 6;
            this.button1.Text = "Xem thông tin nhân viên";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(379, 13);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(156, 26);
            this.button2.TabIndex = 7;
            this.button2.Text = "Xem thông báo";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // fQLTaiNguyenNhanSu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(569, 432);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tabPage);
            this.MaximizeBox = false;
            this.Name = "fQLTaiNguyenNhanSu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý tài nguyên và nhân sự";
            this.tabPage4.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTNNSPCong)).EndInit();
            this.panel19.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTNNSPhong)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTNNSNV)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvTNNSLoaiNV)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabPage.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.DataGridView dtgvTNNSPCong;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Button btnTNNSPCongThem;
        private System.Windows.Forms.Button btnTNNSPCongSua;
        private System.Windows.Forms.Button btnTNNSPCongXoa;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.ComboBox cbxTNNSPCongMaNV;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.DateTimePicker dtpkTNNSNgLamViec;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.DataGridView dtgvTNNSPhong;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button btnTNNSPhongThem;
        private System.Windows.Forms.Button btnTNNSPhongSua;
        private System.Windows.Forms.Button btnTNNSPhongXoa;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TextBox txbTNNSTenPhong;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txbHienThiMaNV;
        private System.Windows.Forms.ComboBox cbxTNNSMaNV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dtgvTNNSNV;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button btnTNNSNVThem;
        private System.Windows.Forms.Button btnTNNSNVSua;
        private System.Windows.Forms.Button btnTNNSNVXoa;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.ComboBox cbxTNNSNV_MaPhong;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.ComboBox cbxTNNSNV_LoaiNV;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txbTNNSChucVu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txbTNNSTenNV;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dtgvTNNSLoaiNV;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btnTNNSLoaiNVThem;
        private System.Windows.Forms.Button btnTNNSLoaiNVSua;
        private System.Windows.Forms.Button btnTNNSLoaiNVXoa;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txbTNNSTenLoaiNV;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabControl tabPage;
        private System.Windows.Forms.TextBox txbHienThiPC;
        private System.Windows.Forms.TextBox txbTNNSDen;
        private System.Windows.Forms.TextBox txbTNNSTu;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;

    }
}